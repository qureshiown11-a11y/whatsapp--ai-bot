const Database = require('better-sqlite3');
const path = require('path');

class DatabaseManager {
    constructor() {
        this.db = new Database(path.join(__dirname, 'bot.db'));
        this.initTables();
    }

    initTables() {
        // Business configs table
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS businesses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_number TEXT UNIQUE NOT NULL,
                business_name TEXT,
                business_type TEXT DEFAULT 'general',
                description TEXT,
                language TEXT DEFAULT 'en',
                custom_instructions TEXT,
                active INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Conversations table
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_number TEXT NOT NULL,
                customer_name TEXT,
                message TEXT NOT NULL,
                response TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Pending setups table
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS pending_setups (
                number TEXT PRIMARY KEY,
                pending INTEGER DEFAULT 1
            )
        `);

        // Create indexes
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_conversations_number ON conversations(customer_number)`);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_conversations_date ON conversations(created_at)`);
    }

    // Business Config Methods
    saveBusinessConfig(number, config) {
        const stmt = this.db.prepare(`
            INSERT OR REPLACE INTO businesses 
            (owner_number, business_name, business_type, description, language, custom_instructions)
            VALUES (?, ?, ?, ?, ?, ?)
        `);
        stmt.run(
            number,
            config.business_name || '',
            config.business_type || 'general',
            config.description || '',
            config.language || 'en',
            config.custom_instructions || ''
        );
    }

    getBusinessConfig(number) {
        const stmt = this.db.prepare('SELECT * FROM businesses WHERE owner_number = ? AND active = 1');
        return stmt.get(number);
    }

    updateBusinessConfig(number, updates) {
        const fields = Object.keys(updates).map(k => `${k} = ?`).join(', ');
        const values = Object.values(updates);
        values.push(number);
        
        const stmt = this.db.prepare(`
            UPDATE businesses SET ${fields}, updated_at = CURRENT_TIMESTAMP WHERE owner_number = ?
        `);
        stmt.run(...values);
    }

    deleteBusinessConfig(number) {
        const stmt = this.db.prepare('UPDATE businesses SET active = 0 WHERE owner_number = ?');
        stmt.run(number);
    }

    getAllBusinesses() {
        const stmt = this.db.prepare('SELECT * FROM businesses WHERE active = 1 ORDER BY created_at DESC');
        return stmt.all();
    }

    getActiveBusinesses() {
        return this.getAllBusinesses();
    }

    // Pending Setup Methods
    setPendingSetup(number, pending) {
        if (pending) {
            const stmt = this.db.prepare('INSERT OR REPLACE INTO pending_setups (number, pending) VALUES (?, 1)');
            stmt.run(number);
        } else {
            const stmt = this.db.prepare('DELETE FROM pending_setups WHERE number = ?');
            stmt.run(number);
        }
    }

    isPendingSetup(number) {
        const stmt = this.db.prepare('SELECT * FROM pending_setups WHERE number = ? AND pending = 1');
        return !!stmt.get(number);
    }

    // Conversation Methods
    logConversation(number, name, message, response) {
        const stmt = this.db.prepare(`
            INSERT INTO conversations (customer_number, customer_name, message, response)
            VALUES (?, ?, ?, ?)
        `);
        stmt.run(number, name, message, response);
    }

    getConversations(limit = 50, offset = 0) {
        const stmt = this.db.prepare(`
            SELECT * FROM conversations 
            ORDER BY created_at DESC 
            LIMIT ? OFFSET ?
        `);
        return stmt.all(limit, offset);
    }

    getConversationStats(number) {
        const now = new Date();
        const today = now.toISOString().split('T')[0];
        const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000).toISOString();
        const monthAgo = new Date(now - 30 * 24 * 60 * 60 * 1000).toISOString();

        const total = this.db.prepare(
            'SELECT COUNT(*) as count FROM conversations WHERE customer_number = ?'
        ).get(number)?.count || 0;

        const todayCount = this.db.prepare(
            "SELECT COUNT(*) as count FROM conversations WHERE customer_number = ? AND date(created_at) = ?"
        ).get(number, today)?.count || 0;

        const weekCount = this.db.prepare(
            'SELECT COUNT(*) as count FROM conversations WHERE customer_number = ? AND created_at >= ?'
        ).get(number, weekAgo)?.count || 0;

        const monthCount = this.db.prepare(
            'SELECT COUNT(*) as count FROM conversations WHERE customer_number = ? AND created_at >= ?'
        ).get(number, monthAgo)?.count || 0;

        return {
            total,
            today: todayCount,
            week: weekCount,
            month: monthCount
        };
    }

    getRecentActivity() {
        const stmt = this.db.prepare(`
            SELECT customer_number, customer_name, COUNT(*) as message_count, 
                   MAX(created_at) as last_message
            FROM conversations 
            GROUP BY customer_number 
            ORDER BY last_message DESC 
            LIMIT 10
        `);
        return stmt.all();
    }
}

module.exports = DatabaseManager;
