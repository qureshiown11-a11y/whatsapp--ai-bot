require('dotenv').config();
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const express = require('express');
const cors = require('cors');
const path = require('path');
const Database = require('./database');
const AIService = require('./ai-service');
const OrderManager = require('./order-manager');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Initialize services
const db = new Database();
const ai = new AIService();
const orderManager = new OrderManager(db.db);

// WhatsApp Client
const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    }
});

// Bot state
let botState = {
    connected: false,
    qrCode: null,
    startTime: Date.now(),
    messagesHandled: 0,
    businesses: []
};

// ============ WHATSAPP EVENTS ============

client.on('qr', (qr) => {
    console.log('QR Code received! Scan this with WhatsApp:');
    qrcode.generate(qr, { small: true });
    botState.qrCode = qr;
});

client.on('ready', () => {
    console.log('✅ WhatsApp Bot is ready!');
    botState.connected = true;
    botState.qrCode = null;
});

client.on('authenticated', () => {
    console.log('✅ Authenticated successfully!');
});

client.on('auth_failure', (msg) => {
    console.error('❌ Authentication failed:', msg);
    botState.connected = false;
});

client.on('disconnected', (reason) => {
    console.warn('⚠️ Client disconnected:', reason);
    botState.connected = false;
});

// ============ MESSAGE HANDLER ============

client.on('message', async (msg) => {
    try {
        // Ignore messages from self
        if (msg.fromMe) return;

        const chat = await msg.getChat();
        if (!chat.isGroup) {
            // Get contact info
            const contact = await msg.getContact();
            const senderName = contact.pushname || contact.name || 'Customer';
            const senderNumber = msg.from.replace('@c.us', '');

            console.log(`📩 Message from ${senderName} (${senderNumber}): ${msg.body}`);

            // Get business config for this number
            const businessConfig = db.getBusinessConfig(senderNumber);
            const ownerNumber = businessConfig ? businessConfig.owner_number : null;

            // Check if this is a command
            if (msg.body.startsWith('/')) {
                await handleCommand(msg, senderNumber);
                return;
            }

            // Get AI response
            const context = {
                senderName,
                senderNumber,
                message: msg.body,
                businessType: businessConfig?.business_type || 'general',
                businessName: businessConfig?.business_name || 'Business',
                language: businessConfig?.language || process.env.DEFAULT_LANGUAGE || 'en',
                customInstructions: businessConfig?.custom_instructions || ''
            };

            const aiResponse = await ai.getResponse(context);

            // Send AI response
            await msg.reply(aiResponse);
            botState.messagesHandled++;

            // Log conversation
            db.logConversation(senderNumber, senderName, msg.body, aiResponse);

            console.log(`✅ Replied to ${senderName}: ${aiResponse.substring(0, 50)}...`);

        } else {
            // Group message handling
            const groupName = chat.name;
            console.log(`📩 Group message in ${groupName}: ${msg.body}`);
            
            // Only respond if mentioned
            if (msg.body.includes(`@${client.info.wid.user}`)) {
                const contact = await msg.getContact();
                const senderName = contact.pushname || contact.name || 'User';
                
                const context = {
                    senderName,
                    message: msg.body.replace(`@${client.info.wid.user}`, '').trim(),
                    businessType: 'general',
                    businessName: 'Group Chat',
                    language: process.env.DEFAULT_LANGUAGE || 'en',
                    customInstructions: ''
                };

                const aiResponse = await ai.getResponse(context);
                await msg.reply(aiResponse);
                botState.messagesHandled++;
            }
        }
    } catch (error) {
        console.error('Error handling message:', error);
        try {
            await msg.reply('Sorry, I encountered an error. Please try again later.');
        } catch (e) {
            console.error('Error sending error message:', e);
        }
    }
});

// ============ COMMAND HANDLER ============

async function handleCommand(msg, senderNumber) {
    const command = msg.body.split(' ')[0].toLowerCase();
    const args = msg.body.split(' ').slice(1).join(' ');

    switch (command) {
        case '/help':
            await msg.reply(
                `🤖 *WhatsApp AI Bot Commands*\n\n` +
                `*Basic Commands:*\n` +
                `/help - Show this help menu\n` +
                `/status - Check bot status\n` +
                `/setup - Setup your business profile\n` +
                `/reset - Reset your business profile\n` +
                `/stats - View your conversation stats\n` +
                `/language <code> - Set language (en/ur/hi/ar)\n\n` +
                `*Menu Commands:*\n` +
                `/menu - Show your menu\n` +
                `/menu add <name> <price> [category] - Add menu item\n` +
                `/menu list - List all menu items\n` +
                `/menu remove <id> - Remove menu item\n\n` +
                `*Order Commands:*\n` +
                `/order <items> - Place an order\n` +
                `/orders - View all orders\n` +
                `/orders pending - View pending orders\n` +
                `/order complete <id> - Mark order complete\n` +
                `/order stats - View order statistics\n\n` +
                `_For admin access, visit the dashboard_`
            );
            break;

        case '/status':
            const uptime = Math.floor((Date.now() - botState.startTime) / 1000);
            const hours = Math.floor(uptime / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            await msg.reply(
                `🟢 *Bot Status*\n\n` +
                `Status: Online\n` +
                `Uptime: ${hours}h ${minutes}m\n` +
                `Messages Handled: ${botState.messagesHandled}\n` +
                `Active Businesses: ${db.getActiveBusinesses().length}`
            );
            break;

        case '/setup':
            await msg.reply(
                `🏢 *Business Setup*\n\n` +
                `Please send the following details:\n\n` +
                `1️⃣ Business Name\n` +
                `2️⃣ Business Type (restaurant/shop/service/ecommerce)\n` +
                `3️⃣ Brief description of your business\n` +
                `4️⃣ Preferred language (en/ur/hi/ar)\n\n` +
                `_Example:_\n` +
                `Name: Ali's Restaurant\n` +
                `Type: restaurant\n` +
                `Description: We serve Pakistani & Chinese food. Delivery available.\n` +
                `Language: ur`
            );
            db.setPendingSetup(senderNumber, true);
            break;

        case '/reset':
            db.deleteBusinessConfig(senderNumber);
            await msg.reply('✅ Your business profile has been reset.');
            break;

        case '/stats':
            const stats = db.getConversationStats(senderNumber);
            await msg.reply(
                `📊 *Your Stats*\n\n` +
                `Total Conversations: ${stats.total}\n` +
                `Today: ${stats.today}\n` +
                `This Week: ${stats.week}\n` +
                `This Month: ${stats.month}`
            );
            break;

        case '/language':
            if (['en', 'ur', 'hi', 'ar'].includes(args)) {
                db.updateBusinessConfig(senderNumber, { language: args });
                await msg.reply(`✅ Language set to: ${args}`);
            } else {
                await msg.reply('❌ Invalid language. Use: en, ur, hi, or ar');
            }
            break;

        // Menu Commands
        case '/menu':
            const menuArgs = args.split(' ');
            const menuCommand = menuArgs[0]?.toLowerCase();
            
            if (!menuCommand || menuCommand === '') {
                // Show menu
                const menuText = orderManager.formatMenuForWhatsApp(senderNumber);
                await msg.reply(menuText);
            } else if (menuCommand === 'add') {
                // Add menu item: /menu add Burger 250 food
                const itemName = menuArgs[1];
                const itemPrice = parseFloat(menuArgs[2]);
                const itemCategory = menuArgs[3] || 'general';
                
                if (!itemName || !itemPrice) {
                    await msg.reply('❌ Usage: /menu add <name> <price> [category]\nExample: /menu add Burger 250 food');
                } else {
                    orderManager.addMenuItem(senderNumber, itemName, itemPrice, '', itemCategory);
                    await msg.reply(`✅ Menu item added:\n• ${itemName} - Rs. ${itemPrice}\n• Category: ${itemCategory}`);
                }
            } else if (menuCommand === 'list') {
                // List all menu items
                const menu = orderManager.getMenu(senderNumber);
                if (menu.length === 0) {
                    await msg.reply('📋 No menu items yet.\nUse /menu add <name> <price> to add items.');
                } else {
                    let menuList = '📋 *Your Menu*\n\n';
                    menu.forEach((item, index) => {
                        menuList += `${index + 1}. ${item.name} - Rs. ${item.price}\n   Category: ${item.category} | ID: ${item.id}\n`;
                    });
                    menuList += '\nUse /menu remove <id> to delete items.';
                    await msg.reply(menuList);
                }
            } else if (menuCommand === 'remove') {
                // Remove menu item: /menu remove <id>
                const itemId = parseInt(menuArgs[1]);
                if (!itemId) {
                    await msg.reply('❌ Usage: /menu remove <id>\nUse /menu list to see IDs.');
                } else {
                    orderManager.deleteMenuItem(itemId);
                    await msg.reply(`✅ Menu item removed.`);
                }
            } else {
                await msg.reply('❌ Unknown menu command. Use /help for available commands.');
            }
            break;

        // Order Commands
        case '/order':
            const orderArgs = args.split(' ');
            const orderCommand = orderArgs[0]?.toLowerCase();
            
            if (!orderCommand || orderCommand === '') {
                await msg.reply('❌ Usage: /order <items>\nExample: /order 2 Burger, 1 Pizza\n\nOr use:\n/order status - Check your orders\n/order stats - View statistics');
            } else if (orderCommand === 'status') {
                // Check order status
                const orders = orderManager.getCustomerOrders(senderNumber);
                if (orders.length === 0) {
                    await msg.reply('📦 No orders found.');
                } else {
                    let orderStatus = '📦 *Your Orders*\n\n';
                    orders.slice(0, 5).forEach((order, index) => {
                        const items = JSON.parse(order.items);
                        const itemsList = items.map(i => `${i.quantity}x ${i.name}`).join(', ');
                        orderStatus += `${index + 1}. Order #${order.id}\n   Items: ${itemsList}\n   Total: Rs. ${order.total_amount}\n   Status: ${order.status}\n   Date: ${new Date(order.created_at).toLocaleDateString()}\n\n`;
                    });
                    await msg.reply(orderStatus);
                }
            } else if (orderCommand === 'stats') {
                // View order statistics
                const stats = orderManager.getOrderStats(senderNumber);
                await msg.reply(
                    `📊 *Order Statistics*\n\n` +
                    `Total Orders: ${stats.totalOrders}\n` +
                    `Today's Orders: ${stats.todayOrders}\n` +
                    `Pending Orders: ${stats.pendingOrders}\n` +
                    `Total Revenue: Rs. ${stats.totalRevenue}`
                );
            } else {
                // Place new order
                const menu = orderManager.getMenu(senderNumber);
                if (menu.length === 0) {
                    await msg.reply('❌ No menu items available. Add items first with /menu add');
                } else {
                    const parsed = orderManager.parseOrderFromMessage(args, menu);
                    if (parsed.items.length === 0) {
                        await msg.reply('❌ Could not parse order. Please specify items clearly.\nExample: /order 2 Burger, 1 Pizza');
                    } else {
                        const contact = await msg.getContact();
                        const customerName = contact.pushname || contact.name || 'Customer';
                        
                        orderManager.createOrder(
                            senderNumber,
                            customerName,
                            senderNumber, // Business number (for demo, same as customer)
                            parsed.items,
                            parsed.total,
                            ''
                        );
                        
                        const itemsList = parsed.items.map(i => `${i.quantity}x ${i.name} = Rs. ${i.quantity * i.price}`).join('\n');
                        await msg.reply(
                            `✅ *Order Placed!*\n\n` +
                            `Items:\n${itemsList}\n\n` +
                            `Total: Rs. ${parsed.total}\n` +
                            `Status: Pending\n\n` +
                            `Thank you for your order! 🎉`
                        );
                    }
                }
            }
            break;

        case '/orders':
            const ordersFilter = args.toLowerCase();
            let orders;
            
            if (ordersFilter === 'pending') {
                orders = orderManager.getOrders(senderNumber, 'pending');
            } else {
                orders = orderManager.getOrders(senderNumber);
            }
            
            if (orders.length === 0) {
                await msg.reply('📦 No orders found.');
            } else {
                let ordersList = `📦 *Orders*${ordersFilter === 'pending' ? ' (Pending)' : ''}\n\n`;
                orders.slice(0, 10).forEach((order, index) => {
                    const items = JSON.parse(order.items);
                    const itemsList = items.map(i => `${i.quantity}x ${i.name}`).join(', ');
                    ordersList += `${index + 1}. Order #${order.id}\n   Customer: ${order.customer_name}\n   Items: ${itemsList}\n   Total: Rs. ${order.total_amount}\n   Status: ${order.status}\n   Date: ${new Date(order.created_at).toLocaleDateString()}\n\n`;
                });
                ordersList += 'Use /order complete <id> to mark as complete.';
                await msg.reply(ordersList);
            }
            break;

        case '/complete':
            const completeId = parseInt(args);
            if (!completeId) {
                await msg.reply('❌ Usage: /complete <order-id>\nUse /orders to see order IDs.');
            } else {
                orderManager.updateOrderStatus(completeId, 'completed');
                await msg.reply(`✅ Order #${completeId} marked as complete!`);
            }
            break;

        default:
            await msg.reply('❓ Unknown command. Type /help for available commands.');
    }
}

// ============ SETUP MESSAGE HANDLER ============

client.on('message', async (msg) => {
    if (msg.fromMe) return;
    const senderNumber = msg.from.replace('@c.us', '');
    
    if (db.isPendingSetup(senderNumber) && !msg.body.startsWith('/')) {
        const lines = msg.body.split('\n').filter(l => l.trim());
        if (lines.length >= 4) {
            const config = {
                business_name: lines[0].replace(/name:/i, '').trim(),
                business_type: lines[1].replace(/type:/i, '').trim(),
                description: lines[2].replace(/description:/i, '').trim(),
                language: lines[3].replace(/language:/i, '').trim() || 'en'
            };
            
            db.saveBusinessConfig(senderNumber, config);
            db.setPendingSetup(senderNumber, false);
            
            await msg.reply(
                `✅ *Business Profile Created!*\n\n` +
                `Name: ${config.business_name}\n` +
                `Type: ${config.business_type}\n` +
                `Language: ${config.language}\n\n` +
                `🤖 Your AI bot is now active!\n` +
                `Customers will receive smart auto-replies 24/7.`
            );
        }
    }
});

// ============ ADMIN API ============

// Login
app.post('/api/login', (req, res) => {
    const { password } = req.body;
    if (password === process.env.ADMIN_PASSWORD) {
        res.json({ success: true, token: 'admin_token' });
    } else {
        res.status(401).json({ error: 'Invalid password' });
    }
});

// Get bot status
app.get('/api/status', (req, res) => {
    res.json({
        connected: botState.connected,
        qrCode: botState.qrCode,
        uptime: Date.now() - botState.startTime,
        messagesHandled: botState.messagesHandled,
        businesses: db.getAllBusinesses()
    });
});

// Get all businesses
app.get('/api/businesses', (req, res) => {
    res.json(db.getAllBusinesses());
});

// Get conversations
app.get('/api/conversations', (req, res) => {
    const { limit = 50, offset = 0 } = req.query;
    res.json(db.getConversations(parseInt(limit), parseInt(offset)));
});

// Get stats
app.get('/api/stats', (req, res) => {
    res.json({
        totalMessages: botState.messagesHandled,
        totalBusinesses: db.getAllBusinesses().length,
        uptime: Date.now() - botState.startTime,
        recentActivity: db.getRecentActivity()
    });
});

// Update business config
app.put('/api/businesses/:number', (req, res) => {
    const { number } = req.params;
    const config = req.body;
    db.updateBusinessConfig(number, config);
    res.json({ success: true });
});

// Delete business
app.delete('/api/businesses/:number', (req, res) => {
    const { number } = req.params;
    db.deleteBusinessConfig(number);
    res.json({ success: true });
});

// ============ ORDER MANAGEMENT API ============

// Get menu for a business
app.get('/api/menu/:businessNumber', (req, res) => {
    const { businessNumber } = req.params;
    const menu = orderManager.getMenu(businessNumber);
    res.json(menu);
});

// Add menu item
app.post('/api/menu', (req, res) => {
    const { businessNumber, name, price, description, category } = req.body;
    const result = orderManager.addMenuItem(businessNumber, name, price, description, category);
    res.json({ success: true, id: result.lastInsertRowid });
});

// Update menu item
app.put('/api/menu/:itemId', (req, res) => {
    const { itemId } = req.params;
    const updates = req.body;
    orderManager.updateMenuItem(itemId, updates);
    res.json({ success: true });
});

// Delete menu item
app.delete('/api/menu/:itemId', (req, res) => {
    const { itemId } = req.params;
    orderManager.deleteMenuItem(itemId);
    res.json({ success: true });
});

// Get orders for a business
app.get('/api/orders/:businessNumber', (req, res) => {
    const { businessNumber } = req.params;
    const { status } = req.query;
    const orders = orderManager.getOrders(businessNumber, status);
    res.json(orders);
});

// Get order statistics
app.get('/api/order-stats/:businessNumber', (req, res) => {
    const { businessNumber } = req.params;
    const stats = orderManager.getOrderStats(businessNumber);
    res.json(stats);
});

// Update order status
app.put('/api/orders/:orderId', (req, res) => {
    const { orderId } = req.params;
    const { status } = req.body;
    orderManager.updateOrderStatus(orderId, status);
    res.json({ success: true });
});

// ============ START SERVER ============

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`\n🚀 WhatsApp AI Bot Starting...`);
    console.log(`📊 Admin Dashboard: http://localhost:${PORT}`);
    console.log(`\nInitializing WhatsApp Client...`);
    client.initialize();
});

// Graceful shutdown
process.on('SIGINT', async () => {
    console.log('\n⏹️ Shutting down...');
    await client.destroy();
    process.exit(0);
});
