const Database = require('better-sqlite3');
const path = require('path');

class OrderManager {
    constructor(db) {
        this.db = db;
        this.initTables();
    }

    initTables() {
        // Orders table
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_number TEXT NOT NULL,
                customer_name TEXT,
                business_number TEXT NOT NULL,
                items TEXT NOT NULL,
                total_amount REAL DEFAULT 0,
                status TEXT DEFAULT 'pending',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Menu items table
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS menu_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                business_number TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                price REAL NOT NULL,
                category TEXT DEFAULT 'general',
                available INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Create indexes
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_number)`);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_orders_business ON orders(business_number)`);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_menu_business ON menu_items(business_number)`);
    }

    // Menu Management
    addMenuItem(businessNumber, name, price, description = '', category = 'general') {
        const stmt = this.db.prepare(`
            INSERT INTO menu_items (business_number, name, price, description, category)
            VALUES (?, ?, ?, ?, ?)
        `);
        return stmt.run(businessNumber, name, price, description, category);
    }

    getMenu(businessNumber) {
        const stmt = this.db.prepare(`
            SELECT * FROM menu_items 
            WHERE business_number = ? AND available = 1 
            ORDER BY category, name
        `);
        return stmt.all(businessNumber);
    }

    getMenuByCategory(businessNumber) {
        const items = this.getMenu(businessNumber);
        const categorized = {};
        
        items.forEach(item => {
            if (!categorized[item.category]) {
                categorized[item.category] = [];
            }
            categorized[item.category].push(item);
        });
        
        return categorized;
    }

    updateMenuItem(itemId, updates) {
        const fields = Object.keys(updates).map(k => `${k} = ?`).join(', ');
        const values = Object.values(updates);
        values.push(itemId);
        
        const stmt = this.db.prepare(`UPDATE menu_items SET ${fields} WHERE id = ?`);
        return stmt.run(...values);
    }

    deleteMenuItem(itemId) {
        const stmt = this.db.prepare('DELETE FROM menu_items WHERE id = ?');
        return stmt.run(itemId);
    }

    // Order Management
    createOrder(customerNumber, customerName, businessNumber, items, totalAmount, notes = '') {
        const stmt = this.db.prepare(`
            INSERT INTO orders (customer_number, customer_name, business_number, items, total_amount, notes)
            VALUES (?, ?, ?, ?, ?, ?)
        `);
        return stmt.run(customerNumber, customerName, businessNumber, JSON.stringify(items), totalAmount, notes);
    }

    getOrders(businessNumber, status = null) {
        let query = 'SELECT * FROM orders WHERE business_number = ?';
        const params = [businessNumber];
        
        if (status) {
            query += ' AND status = ?';
            params.push(status);
        }
        
        query += ' ORDER BY created_at DESC';
        
        const stmt = this.db.prepare(query);
        return stmt.all(...params);
    }

    getCustomerOrders(customerNumber) {
        const stmt = this.db.prepare(`
            SELECT * FROM orders 
            WHERE customer_number = ? 
            ORDER BY created_at DESC
        `);
        return stmt.all(customerNumber);
    }

    updateOrderStatus(orderId, status) {
        const stmt = this.db.prepare(`
            UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
        `);
        return stmt.run(status, orderId);
    }

    getOrderStats(businessNumber) {
        const today = new Date().toISOString().split('T')[0];
        
        const totalOrders = this.db.prepare(
            'SELECT COUNT(*) as count FROM orders WHERE business_number = ?'
        ).get(businessNumber)?.count || 0;

        const todayOrders = this.db.prepare(
            "SELECT COUNT(*) as count FROM orders WHERE business_number = ? AND date(created_at) = ?"
        ).get(businessNumber, today)?.count || 0;

        const totalRevenue = this.db.prepare(
            "SELECT SUM(total_amount) as total FROM orders WHERE business_number = ? AND status = 'completed'"
        ).get(businessNumber)?.total || 0;

        const pendingOrders = this.db.prepare(
            "SELECT COUNT(*) as count FROM orders WHERE business_number = ? AND status = 'pending'"
        ).get(businessNumber)?.count || 0;

        return {
            totalOrders,
            todayOrders,
            totalRevenue,
            pendingOrders
        };
    }

    // Format menu for WhatsApp
    formatMenuForWhatsApp(businessNumber) {
        const menu = this.getMenuByCategory(businessNumber);
        
        if (Object.keys(menu).length === 0) {
            return '📋 *Menu*\n\nMenu abhi available nahi hai. Baad mein check karein.';
        }

        let message = '📋 *Our Menu*\n\n';
        
        for (const [category, items] of Object.entries(menu)) {
            message += `*${category.toUpperCase()}*\n`;
            items.forEach(item => {
                message += `• ${item.name} - Rs. ${item.price}\n`;
                if (item.description) {
                    message += `  _${item.description}_\n`;
                }
            });
            message += '\n';
        }
        
        message += 'Order karne ke liye items batayein! 🛒';
        
        return message;
    }

    // Parse order from message
    parseOrderFromMessage(message, menu) {
        const items = [];
        let total = 0;
        
        // Simple parsing - look for item names and quantities
        const lines = message.toLowerCase().split('\n');
        
        for (const line of lines) {
            for (const menuItem of menu) {
                if (line.includes(menuItem.name.toLowerCase())) {
                    // Try to extract quantity
                    const quantityMatch = line.match(/(\d+)\s*(?:x|pcs|pieces)?/);
                    const quantity = quantityMatch ? parseInt(quantityMatch[1]) : 1;
                    
                    items.push({
                        name: menuItem.name,
                        price: menuItem.price,
                        quantity: quantity
                    });
                    
                    total += menuItem.price * quantity;
                }
            }
        }
        
        return { items, total };
    }
}

module.exports = OrderManager;
