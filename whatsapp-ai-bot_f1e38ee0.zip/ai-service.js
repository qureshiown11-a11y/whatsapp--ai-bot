const OpenAI = require('openai');

class AIService {
    constructor() {
        this.client = new OpenAI({
            apiKey: process.env.OPENAI_API_KEY
        });
        this.model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
    }

    async getResponse(context) {
        const {
            senderName,
            senderNumber,
            message,
            businessType,
            businessName,
            language,
            customInstructions
        } = context;

        // Build system prompt based on business type and language
        const systemPrompt = this.buildSystemPrompt({
            businessType,
            businessName,
            language,
            customInstructions
        });

        // Build user message with context
        const userMessage = this.buildUserMessage({
            senderName,
            message,
            language
        });

        try {
            const response = await this.client.chat.completions.create({
                model: this.model,
                messages: [
                    { role: 'system', content: systemPrompt },
                    { role: 'user', content: userMessage }
                ],
                max_tokens: 500,
                temperature: 0.7
            });

            return response.choices[0].message.content.trim();
        } catch (error) {
            console.error('AI API Error:', error.message);
            return this.getFallbackResponse(language);
        }
    }

    buildSystemPrompt({ businessType, businessName, language, customInstructions }) {
        const langInstructions = this.getLanguageInstructions(language);
        
        let prompt = `You are an AI customer service assistant for "${businessName}".
Business Type: ${businessType}
${langInstructions}

Your role:
- Respond professionally and helpfully to customer inquiries
- Provide accurate information about the business
- Be friendly, polite, and concise
- If you don't know specific details (prices, hours, etc.), politely ask them to contact the owner directly
- Keep responses short and to the point (2-4 sentences max)
- Use appropriate formatting (bold for emphasis, lists when needed)
`;

        if (businessType === 'restaurant') {
            prompt += `
- For food orders: ask for items, quantities, and delivery address
- For reservations: ask for date, time, and number of people
- For menu questions: provide general guidance and suggest contacting for full menu
`;
        } else if (businessType === 'ecommerce') {
            prompt += `
- For product inquiries: provide general product information
- For orders: ask for order details and confirm availability
- For shipping: provide general shipping information
- For returns: explain general return policy
`;
        } else if (businessType === 'service') {
            prompt += `
- For appointments: ask for preferred date/time and service type
- For pricing: provide general pricing information
- For availability: check and confirm booking slots
`;
        } else if (businessType === 'shop') {
            prompt += `
- For product availability: provide general information
- For pricing: give approximate ranges when possible
- For store hours: provide general information
`;
        }

        if (customInstructions) {
            prompt += `\nAdditional Instructions: ${customInstructions}\n`;
        }

        return prompt;
    }

    buildUserMessage({ senderName, message, language }) {
        return `Customer name: ${senderName}
Customer message: ${message}

Please respond to this customer message appropriately.`;
    }

    getLanguageInstructions(language) {
        const instructions = {
            en: 'Respond in English. Be professional and friendly.',
            ur: 'Urdu mein jawab dein. Professional aur friendly rahein. Roman Urdu use karein.',
            hi: 'Hindi mein jawab dein. Professional aur friendly rahein. Roman Hindi use karein.',
            ar: 'Respond in Arabic. Be professional and friendly.',
            mixed: 'Respond in the same language the customer uses. Support English, Urdu, Hindi, and Arabic.'
        };
        return instructions[language] || instructions.en;
    }

    getFallbackResponse(language) {
        const responses = {
            en: 'Thank you for your message! I\'m currently experiencing technical difficulties. Please try again in a few moments, or contact us directly.',
            ur: 'Aapke message ka shukriya! Main filhal technical maslay ka shikaar hoon. Baraye meherbani kuch dair baad dobara koshish karein.',
            hi: 'Aapke message ke liye dhanyavaad! Main abhi takniki samasya ka samna kar raha hoon. Kripya kuch der baad punah prayaas karein.',
            ar: 'شكراً لرسالتك! أنا أعاني حالياً من صعوبات فنية. يرجى المحاولة مرة أخرى بعد قليل.'
        };
        return responses[language] || responses.en;
    }
}

module.exports = AIService;
